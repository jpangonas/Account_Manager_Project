package acctMgr.model;

// TODO: Auto-generated Javadoc
/**
 * The Interface Model.
 */
public interface Model {
	
	/**
	 * Notify changed.
	 *
	 * @param me the me
	 */
	public void notifyChanged(ModelEvent me);
}
