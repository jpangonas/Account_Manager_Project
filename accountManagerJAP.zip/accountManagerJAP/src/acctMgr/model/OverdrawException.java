package acctMgr.model;

import java.math.BigDecimal;
// TODO: Auto-generated Javadoc

/**
 * The Class OverdrawException.
 *
 * @author Jacob Pangonas
 */
public class OverdrawException extends Exception {
	
	/**
	 * Instantiates a new overdraw exception.
	 *
	 * @param amt the amt
	 */
	OverdrawException(BigDecimal amt){
		super("Insufficient funds");
	}
}

