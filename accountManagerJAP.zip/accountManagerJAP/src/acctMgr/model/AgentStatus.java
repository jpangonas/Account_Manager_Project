package acctMgr.model;

public enum AgentStatus {
	Running, Blocked, Paused, NA
}
