package acctMgr.view;
import acctMgr.controller.Controller;
import acctMgr.model.Model;
// TODO: Auto-generated Javadoc

/**
 * The Interface View.
 */
public interface View {
	
	/**
	 * Gets the controller.
	 *
	 * @return the controller
	 */
	Controller getController();
	
	/**
	 * Sets the controller.
	 *
	 * @param aController the new controller
	 */
	public void setController(Controller aController);
	
	/**
	 * Gets the model.
	 *
	 * @return the model
	 */
	public Model getModel();
	
	/**
	 * Sets the model.
	 *
	 * @param aModel the new model
	 */
	public void setModel(Model aModel);
}
