package acctMgr.view;

import javax.swing.*;

/**
 * The Class JFramePanel.
 */
public class JFramePanel extends JPanel {
}
