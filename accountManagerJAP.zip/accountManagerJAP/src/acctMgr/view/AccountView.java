package acctMgr.view;

import acctMgr.controller.Controller;
import acctMgr.controller.AccountController;
import acctMgr.controller.AgentController;
import acctMgr.model.Model;
import acctMgr.model.Account;
import acctMgr.model.AccountList;
import acctMgr.model.Agent;
import acctMgr.model.ModelEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountView.
 *
 * @author Jacob Pangonas
 */
public class AccountView extends JFrameView {

	/** The Constant Withdraw. */
	public final static String Withdraw = "Withdraw";
	
	/** The Constant Save. */
	public final static String Save = "    Save     ";
	
	/** The Constant StartDepAgent. */
	public final static String StartDepAgent = "      StartDepAgent     ";
	
	/** The Constant StartWithdrawAgent. */
	public final static String StartWithdrawAgent = "StartWithdrawAgent";
	
	/** The Constant SaveAndExit. */
	public final static String SaveAndExit = "       Save and Exit      ";
	
	/** The Constant Deposit. */
	public final static String Deposit = "  Deposit  ";
	
	/** The account view. */
	public static Object accountView;
	
	/** The init amount S. */
	private String initAmountS;
	
	/** The agent contrs. */
	private List<AgentController> agentContrs = new ArrayList<AgentController>(10);
	
	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		BigDecimal amount = BigDecimal.ZERO;
		try {
			amount = new BigDecimal(amountField.getText());
			
		}
		catch(NumberFormatException ex) {
			amountField.setText(initAmountS);
			showError("Amount field only accepts decimals");
		}
		return amount;
	}
	
	/**
	 * Show error.
	 *
	 * @param msg the msg
	 */
	public void showError(String msg) {
		JOptionPane.showMessageDialog(this, msg);
	}

	/**
	 * Instantiates a new account view.
	 *
	 * @param model the model
	 * @param controller the controller
	 */
	private AccountView(Model model, Controller controller){
		super(model, controller);
		initAmountS = "30.00";
		this.getContentPane().add(getContent());


		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				super.windowClosing(evt);
				AccountList.end();
				System.exit(0);
			}
		});

		setLocation(400, 300);
		pack();
	}
	
	/**
	 * Account view.
	 *
	 * @param account the account
	 */
	public static void accountView(Account account) {
		final AccountController contr = new AccountController();
		contr.setModel(account);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AccountView app = new AccountView(account, contr);
				contr.setView(app);
				app.setVisible(true);
			}
		});
	}
	
	/**
	 * Creates the agent view.
	 *
	 * @param ag the ag
	 * @param agContr the ag contr
	 * @return the agent view
	 */
	public AgentView createAgentView(Agent ag, AgentController agContr){
		AgentView app = new AgentView(ag, agContr);
		agContr.setView(app);
		agentContrs.add(agContr);
		app.setVisible(true);
		return app;
	}

	/** The balance field. */
	private JTextPane balanceField;
	
	/**
	 * Gets the balance field.
	 *
	 * @return the balance field
	 */
	private JTextPane getBalanceField(){
		if(balanceField == null){
			balanceField = new JTextPane();
			balanceField.setText((((Account)getModel()).getBalance()).toString());
			balanceField.setSize(200, 25);
			balanceField.setEditable(false);
		}
		return balanceField;
	}
	
	/** The amount field. */
	private JTextPane amountField;
	
	/**
	 * Gets the amount field.
	 *
	 * @return the amount field
	 */
	private JTextPane getAmountField(){
		if(amountField == null){
			amountField = new JTextPane();

			amountField.addKeyListener(new KeyAdapter() {
				public void keyTyped(KeyEvent e) {
					char c = e.getKeyChar();
					if ( ((c < '0') || (c > '9')) || c == KeyEvent.VK_PERIOD || c == KeyEvent.VK_DECIMAL) {
						e.consume();  
					}
				}
			});

			amountField.setText(initAmountS);
			amountField.setSize(200, 25);
			amountField.setEditable(true);
		}
		return amountField;
	}

	/** The top panel. */
	private JPanel topPanel;
	
	/** The text panel. */
	private JPanel textPanel;

	/**
	 * Gets the content.
	 *
	 * @return the content
	 */
	private JPanel getContent() {
		if (topPanel == null) {
			topPanel = new JPanel();
			GridLayout layout = new GridLayout(2, 1);
			topPanel.setLayout(layout);
			topPanel.setPreferredSize(new Dimension(500, 500));
			GridBagConstraints ps = new GridBagConstraints();
			ps.gridx = 0;
			ps.gridy = 0;
			ps.fill = GridBagConstraints.HORIZONTAL;

			GridBagConstraints bs = new GridBagConstraints();
			bs.gridx = 0;
			bs.gridy = 1;
			topPanel.add(getTextFieldPanel(), null);
			topPanel.add(getButtonPanel(), null);
		}
		return topPanel;
	}
	
	/**
	 * Gets the text field panel.
	 *
	 * @return the text field panel
	 */
	private JPanel getTextFieldPanel()
	{
		if(textPanel == null){
			GridBagConstraints bl = new GridBagConstraints();
			bl.gridx = 0;
			bl.gridy = 0;

			GridBagConstraints bf = new GridBagConstraints();
			bf.gridx = 1;
			bf.gridy = 0;

			GridBagConstraints aml = new GridBagConstraints();
			aml.gridx = 0;
			aml.gridy = 1;

			GridBagConstraints amf = new GridBagConstraints();
			amf.gridx = 1;
			amf.gridy = 1;

			textPanel = new JPanel();
			textPanel.setBackground(Color.BLACK);
			textPanel.setLayout(new GridBagLayout());
			textPanel.setPreferredSize(new Dimension(400, 75));
			textPanel.add(getBalanceLabel(), bl);
			textPanel.add(getBalanceField(), bf);
			textPanel.add(getAmountLabel(), aml);
			textPanel.add(getAmountField(), amf);

		}
		return textPanel;
	}

	/** The balance label. */
	private JLabel balanceLabel;
	
	/**
	 * Gets the balance label.
	 *
	 * @return the balance label
	 */
	private JLabel getBalanceLabel(){
		if(balanceLabel == null){
			balanceLabel = new JLabel();
			balanceLabel.setText("Balance:");
			balanceLabel.setPreferredSize(new Dimension(200, 200));
		}
		return balanceLabel;
	}
	
	/** The amount label. */
	private JLabel amountLabel;
	
	/**
	 * Gets the amount label.
	 *
	 * @return the amount label
	 */
	private JLabel getAmountLabel(){
		if(amountLabel == null){
			amountLabel = new JLabel();
			amountLabel.setText("Amount:");
			amountLabel.setPreferredSize(new Dimension(200, 100));
		}
		return amountLabel;
	}
	
	/** The button panel. */
	private JPanel buttonPanel;
	
	/**
	 * Gets the button panel.
	 *
	 * @return the button panel
	 */
	private JPanel getButtonPanel()
	{
		if(buttonPanel == null){
			GridBagConstraints depButtonCtr = new GridBagConstraints();
			depButtonCtr.gridx = 1;
			depButtonCtr.gridy = 1;

			GridBagConstraints wButtonCtr = new GridBagConstraints();
			wButtonCtr.gridx = 1;
			wButtonCtr.gridy = 0;
			
			GridBagConstraints depAgButtonCtr = new GridBagConstraints();
            depAgButtonCtr.gridx = 2;
            depAgButtonCtr.gridy = 1;

            GridBagConstraints wAgButtonCtr = new GridBagConstraints();
            wAgButtonCtr.gridx = 2;
            wAgButtonCtr.gridy = 0;
            		
			GridBagConstraints saveButtonCtr = new GridBagConstraints();
			saveButtonCtr.gridx = 1;
			saveButtonCtr.gridy = 5;

			GridBagConstraints saveAndExitButtonCtr = new GridBagConstraints();
			saveAndExitButtonCtr.gridx = 2;
			saveAndExitButtonCtr.gridy = 5;

			buttonPanel = new JPanel();
			buttonPanel.setBackground(Color.BLACK);
			buttonPanel.setLayout(new GridBagLayout());
			buttonPanel.add(getDepButton(), depButtonCtr);
			buttonPanel.add(getWithdrawButton(), wButtonCtr);
			buttonPanel.add(getDepAgentButton(), depAgButtonCtr);
			buttonPanel.add(getWithdrawAgentButton(), wAgButtonCtr);
			buttonPanel.add(getSaveButton(), saveButtonCtr);
			buttonPanel.add(getSaveExitButton(), saveAndExitButtonCtr);
		}

		return buttonPanel;
	}


	/** The save exit button. */
	private JButton saveExitButton;
	
	/**
	 * Gets the save exit button.
	 *
	 * @return the save exit button
	 */
	private JButton getSaveExitButton(){
		if(saveExitButton == null){
			saveExitButton = new JButton(SaveAndExit);
			saveExitButton.setBackground(Color.ORANGE);
			saveExitButton.addActionListener(handler);
		}
		return saveExitButton;
	}

	/** The save button. */
	private JButton saveButton;
	
	/**
	 * Gets the save button.
	 *
	 * @return the save button
	 */
	private JButton getSaveButton(){
		if(saveButton == null){
			saveButton = new JButton(Save);
			saveButton.setBackground(Color.CYAN);
			saveButton.addActionListener(handler);
		}
		return saveButton;
	}
	
	/** The start withdraw agent button. */
	private JButton startWithdrawAgentButton;
	
	/**
	 * Gets the withdraw agent button.
	 *
	 * @return the withdraw agent button
	 */
	private JButton getWithdrawAgentButton(){
		if(startWithdrawAgentButton == null){
			startWithdrawAgentButton = new JButton(StartWithdrawAgent);
			startWithdrawAgentButton.setBackground(Color.YELLOW);
			startWithdrawAgentButton.addActionListener(handler);
		}
		return startWithdrawAgentButton;
	}
	
	/** The start dep agent button. */
	private JButton startDepAgentButton;
	
	/**
	 * Gets the dep agent button.
	 *
	 * @return the dep agent button
	 */
	private JButton getDepAgentButton(){
		if(startDepAgentButton == null){
			startDepAgentButton = new JButton(StartDepAgent);
			startDepAgentButton.setBackground(Color.BLUE);
			startDepAgentButton.addActionListener(handler);
		}
		return startDepAgentButton;
	}
	
	/** The withdraw button. */
	private JButton withdrawButton;
	
	/**
	 * Gets the withdraw button.
	 *
	 * @return the withdraw button
	 */
	private JButton getWithdrawButton(){
		if(withdrawButton == null){
			withdrawButton = new JButton(Withdraw);
			withdrawButton.setBackground(Color.RED);
			withdrawButton.addActionListener(handler);
		}
		return withdrawButton;
	}

	/** The dep button. */
	private JButton depButton;
	
	/**
	 * Gets the dep button.
	 *
	 * @return the dep button
	 */
	private JButton getDepButton(){
		if(depButton == null){
			depButton = new JButton(Deposit);
			depButton.setBackground(Color.GREEN);
			depButton.addActionListener(handler);
		}
		return depButton;
	}

	/** The handler. */
	private Handler handler = new Handler();
	
	/**
	 * The Class Handler.
	 */
	private class Handler implements ActionListener {
		

		public void actionPerformed(ActionEvent evt) {
			((AccountController)getController()).operation(evt.getActionCommand());
		}
	}
	

	public void modelChanged(ModelEvent me){
		if(me.getKind() == ModelEvent.EventKind.BalanceUpdate) {
			System.out.println("Balance field to " + me.getBalance());
			balanceField.setText((me.getBalance()).toString());
		}
	}
}
