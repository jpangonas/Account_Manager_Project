package acctMgr.view;

import acctMgr.model.Model;
import acctMgr.model.ModelEvent;
import acctMgr.controller.Controller;
// TODO: Auto-generated Javadoc

/**
 * The Class AppFrame.
 */
public class AppFrame extends JFrameView {
    
    /** The base panel. */
    private JFramePanel basePanel;

    /**
     * Instantiates a new app frame.
     *
     * @param model the model
     * @param controller the controller
     */
    public AppFrame(Model model, Controller controller) {
        super(model, controller);
    }

    @Override
    public void modelChanged(ModelEvent me) {

    }
}
