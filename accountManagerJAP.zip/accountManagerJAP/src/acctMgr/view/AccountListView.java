package acctMgr.view;

import acctMgr.controller.AccountListController;
import acctMgr.controller.Controller;
import acctMgr.model.Account;
import acctMgr.model.AccountList;
import acctMgr.model.Model;
import acctMgr.model.ModelEvent;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;
// TODO: Auto-generated Javadoc

/**
 * The Class AccountListView.
 *
 * @author Jacob Pangonas
 */
public class AccountListView extends JFrameView {
    
    /** The Constant Save. */
    public final static String Save = "             Save           ";
    
    /** The Constant SaveAndExit. */
    public final static String SaveAndExit = "     Save and Exit     ";
    
    /** The Constant EditInDollars. */
    public final static String EditInDollars = "Change in Dollars ";
    
    /** The Constant EditInEuros. */
    public final static String EditInEuros = " Change in Euros ";
    
    /** The Constant EditInYen. */
    public final static String EditInYen = "    Change in Yen    ";


    /** The account list array. */
    static Vector<String> accountListArray = new Vector<String>();
    
    /** The top panel. */
    private JPanel topPanel;
    
    /** The account list box. */
    private JComboBox accountListBox;
    
    /**
     * Gets the box.
     *
     * @return the box
     */
    private JComboBox getBox() {
        if (accountListBox == null){
            accountListBox = new JComboBox(accountListArray);
            accountListBox.addActionListener(handler);
        }
        return accountListBox;
    }

    /**
     * Gets the content.
     *
     * @return the content
     */
    private JPanel getContent() {
        if(topPanel == null){
            topPanel = new JPanel();
            topPanel.setBackground(Color.BLACK);
            topPanel.add(getBox());
            topPanel.add(getSaveExitButton());
            topPanel.add(getButtonPanel(), null);
        }
        return topPanel;
    }
    
    /** The button panel. */
    private JPanel buttonPanel;

    /**
     * Gets the button panel.
     *
     * @return the button panel
     */
    private JPanel getButtonPanel()
    {
        if(buttonPanel == null){
            GridBagConstraints depButtonCtr = new GridBagConstraints();
            depButtonCtr.gridx = 0;
            depButtonCtr.gridy = 0;

            GridBagConstraints wButtonCtr = new GridBagConstraints();
            wButtonCtr.gridx = 1;
            wButtonCtr.gridy = 0;

            GridBagConstraints saveButtonCtr = new GridBagConstraints();
            saveButtonCtr.gridx = 2;
            saveButtonCtr.gridy = 3;

            GridBagConstraints saveAndExitButtonCtr = new GridBagConstraints();
            saveAndExitButtonCtr.gridx = 4;
            saveAndExitButtonCtr.gridy = 3;

            GridBagConstraints dolButtonCtr = new GridBagConstraints();
            dolButtonCtr.gridx = 2;
            dolButtonCtr.gridy = 1;

            GridBagConstraints eurButtonCtr = new GridBagConstraints();
            eurButtonCtr.gridx = 3;
            eurButtonCtr.gridy = 1;

            GridBagConstraints yenButtonCtr = new GridBagConstraints();
            yenButtonCtr.gridx = 4;
            yenButtonCtr.gridy = 1;

            buttonPanel = new JPanel();
            buttonPanel.setBackground(Color.BLACK);
            buttonPanel.setLayout(new GridBagLayout());
            buttonPanel.add(getSaveButton(), saveButtonCtr);
            buttonPanel.add(getSaveExitButton(), saveAndExitButtonCtr);
            buttonPanel.add(getEditDollarsButton(), dolButtonCtr);
            buttonPanel.add(getEditEurosButton(), eurButtonCtr);
            buttonPanel.add(getEditYenButton(), yenButtonCtr);
        }

        return buttonPanel;
    }

    /** The save exit button. */
    private JButton saveExitButton;
    
    /**
     * Gets the save exit button.
     *
     * @return the save exit button
     */
    private JButton getSaveExitButton(){
        if(saveExitButton == null){
            saveExitButton = new JButton(SaveAndExit);
            saveExitButton.setBackground(Color.ORANGE);
            saveExitButton.addActionListener(ButtonHandler);
        }
        return saveExitButton;
    }
    
    /** The save button. */
    private JButton saveButton;
    
    /**
     * Gets the save button.
     *
     * @return the save button
     */
    private JButton getSaveButton(){
        if(saveButton == null){
            saveButton = new JButton(Save);
            saveButton.setBackground(Color.CYAN);
            saveButton.addActionListener(ButtonHandler);
        }
        return saveButton;
    }
    
    /** The Edit dollars. */
    private JButton EditDollars;
    
    /**
     * Gets the edits the dollars button.
     *
     * @return the edits the dollars button
     */
    private JButton getEditDollarsButton() {
        if (EditDollars == null) {
            EditDollars = new JButton(EditInDollars);
            EditDollars.setBackground(Color.GREEN);
            EditDollars.addActionListener(ButtonHandler);
        }
        return EditDollars;
    }
    
    /** The Edit yen. */
    private JButton EditYen;
    
    /**
     * Gets the edits the yen button.
     *
     * @return the edits the yen button
     */
    private JButton getEditYenButton() {
        if (EditYen == null) {
            EditYen = new JButton(EditInYen);
            EditYen.setBackground(Color.RED);
            EditYen.addActionListener(ButtonHandler);
        }
        return EditYen;
    }
    
    /** The Edit euros. */
    private JButton EditEuros;
    
    /**
     * Gets the edits the euros button.
     *
     * @return the edits the euros button
     */
    private JButton getEditEurosButton() {
        if (EditEuros == null) {
            EditEuros = new JButton(EditInEuros);
            EditEuros.setBackground(Color.GRAY);
            EditEuros.addActionListener(ButtonHandler);
        }
        return EditEuros;
    }


    /** The handler. */
    private Handler handler = new Handler();
    
    /**
     * The Class Handler.
     */
    private class Handler implements ActionListener {
        

        public void actionPerformed(ActionEvent evt) {
        }
    }
    
    /** The Button handler. */
    private ButtonHandler ButtonHandler = new ButtonHandler();
    
    /**
     * The Class ButtonHandler.
     */
    private class ButtonHandler implements ActionListener {
        

        public void actionPerformed(ActionEvent evt) {
            ((AccountListController)getController()).buttonOperation(evt.getActionCommand(), accountListBox.getSelectedIndex());
        }
    }
    
    /**
     * Instantiates a new account list view.
     *
     * @param model the model
     * @param controller the controller
     */
    public AccountListView(Model model, Controller controller) {
        super(model, controller);
        this.getContentPane().add(getContent());
        addWindowListener(new java.awt.event.WindowAdapter(){
            public void windowClosing(java.awt.event.WindowEvent evt){
                setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            }
        });
        pack();
    }


    public void modelChanged(ModelEvent me) { }


    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        File file = new File ("./src/acctMgr/controller/data.txt");
        AccountList accts = new AccountList();
        accts.load(file);
        for( int i = 0; i < AccountList.getAccountList().size(); i++){
        	ArrayList anAccount = AccountList.getAccountList();
            Account acct = (Account) anAccount.get(i);
            accountListArray.addElement(acct.getName() + " " + acct.getID());
        }
        AccountListController acctsController = new AccountListController();
        acctsController.setModel(accts);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                AccountListView acctsView = new AccountListView(accts, acctsController);
                acctsController.setView(acctsView);
                acctsView.setVisible(true);
            }
        });
    }
}
