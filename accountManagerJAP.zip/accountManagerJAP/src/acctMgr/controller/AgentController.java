package acctMgr.controller;

import acctMgr.model.Agent;
import acctMgr.model.Account;
import acctMgr.model.WithdrawAgent;
import acctMgr.view.AgentView;
/**
 * @author Jacob Pangonas
 * 
 * AgentControler extends AbstractController
 */
public class AgentController extends AbstractController {
/**
 * registers users choice	
 * @param opt takes choice of the user
 */
	public void operation(String opt) {

		if(opt == AgentView.Dismiss) {
			Agent ag = (Agent)getModel();
			AgentView agView = (AgentView)getView();
			if(ag instanceof WithdrawAgent) {
				Account account = ag.getAccount();
				account.removeModelListener(agView);
			}
			ag.finish();
			agView.dispose();
		}
	}
}
